template<class Info>
class linkCutTree {
public:
  // use zero as sentinel
  linkCutTree(int n) : n(n), t(n + 1) { 
    t[0].v.set(); 
  }

  void expose(int x) {
    for (int y = 0; x;) {
      splay(x);
      rs(x) = y;
      pull(x);
      y = x;
      x = fa(x);
    }
  }

  void make_root(int x) {
    expose(x);
    splay(x);
    t[x].rev ^= 1;
  }

  auto query(int x, int y) -> const Info& {
    make_root(x);
    expose(y);
    splay(y);
    return t[y].v;
  }

  // findroot
  int find(int x) {
    expose(x);
    splay(x);
    while (ls(x))
      push(x), x = ls(x);
    splay(x);
    return x;
  }

  bool link(int x, int y) {
    make_root(x);
    if (find(y) != x) {
      fa(x) = y;
      // dfs(1);
      return true;
    }
    return false;
  }

  bool cut(int x, int y) {
    make_root(x);
    if (find(y) == x
        && fa(y) == x && !ls(y)) {
      rs(x) = fa(y) = 0;
      pull(x);
      return true;
    }
    return false;
  }

  template<typename ...Args>
  void modify(int x, Args ...args) {
    splay(x);
    t[x].v.modify(args...);
    pull(x);
  }

  bool same(int x, int y) {
    make_root(x);
    return find(y) == x;
  }

  void dfs(int u, bool use_push = true) {
#ifndef ONLINE_JUDGE
    cerr << "\nrooted u: " << u << ", P = " << t[u].p << '\n';
    dfs(u, 0, use_push);
#endif
  }
private:
  struct node {
    bool rev;
    int s[2], p;
    Info v;
  };
  int n;
  vector<node> t;

  int& fa(int x) { return t[x].p; }
  int& ls(int x) { return t[x].s[0]; }
  int& rs(int x) { return t[x].s[1]; }
  // notroot
  bool pos(int x) {
    return t[t[x].p].s[0] == x || t[t[x].p].s[1] == x;
  }

  // splay function 
  void pull(int x) {
    t[x].v.up(t[ls(x)].v, t[rs(x)].v);
  }

  void push(int x) {
    if (t[x].rev) {
      swap(ls(x), rs(x));
      t[ls(x)].v.reverse();
      t[rs(x)].v.reverse();
      t[rs(x)].rev ^= 1;
      t[ls(x)].rev ^= 1;
      t[x].rev = 0;
    }
  }

  void rotate(int x) {
    int y = fa(x), z = fa(y);
    int k = rs(y) == x;
    if (pos(y))
      t[z].s[rs(z) == y] = x;
    fa(x) = z;
    t[y].s[k] = t[x].s[k ^ 1];
    fa(t[x].s[k ^ 1]) = y;
    t[x].s[k ^ 1] = y;
    fa(y) = x;
    pull(y);
  }

  void up(int x) {
    if (pos(x)) up(fa(x));
    push(x);
  }

  void splay(int x) {
    up(x);
    while (pos(x)) {
      int y = fa(x), z = fa(y);
      if (pos(y))
        ((rs(z) == y) ^ (rs(y) == x))
        ? rotate(x) : rotate(y);
      rotate(x);
    }
    pull(x);
  }

  void dfs(int u, int dep, bool use_push = true) {
    if (!u) {
        return;
    }
    if (use_push) {
      push(u);
    }
    for (auto i : {0, 1}) {
      if (i == 1) {
        cerr << string(dep, '\t');
        cerr << u << ' ' << t[u].v << endl;
      }
      dfs(t[u].s[i], dep + 1, use_push);
    }
  }
};

struct Info {
  // do reverse info here
  void reverse() {

  }
  // modify info
  void modify() {
  }
  // merge left and right and yourself
  void up(const Info &u, 
      const Info &v) {
  }
  // set sentinel val
  void set() {

  }
  // debug
  friend ostream &operator<<(ostream &cout, Info x) {
    return cout;
  };
};